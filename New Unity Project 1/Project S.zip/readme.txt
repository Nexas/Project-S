/******************************************
*
*                Project S
*
*******************************************/

Author: Sean Welch
Build Date: 2/17/2015

DISCLAIMER: This is a work in progress. All textures, characters, and resources are not owned by me, and are being used in a nonprofit project.

Controls:
Arrow Keys - Navigate Menu/field
Z - Confirm/Fire
X - Cancel [Not currently in use]
C - Special [Not currently in use]

Objective:
To clear the level of enemies and defeat the boss waiting at the end of the level. [Levels are not completed, and therefore not completely populated with enemies.]

Cheats:
L - Teleports the player to the boss fight.
T - Puts the boss into his second phase, at 66% health.
U - Puts the boss into his third phase, at 33% health.

All menus, game object placement, and Scripts were all created or performed by myself. Any feedback can be sent to Nexas99@gmail.com. Thanks for playing, and enjoy!